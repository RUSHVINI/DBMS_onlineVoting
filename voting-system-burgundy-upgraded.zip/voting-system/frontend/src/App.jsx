import { useEffect, useState, useCallback } from "react";
import { api } from "./api";

const STEP = { REGISTER: 0, OTP: 1, VOTE: 2, DONE: 3 };

export default function App() {
  const [step, setStep] = useState(STEP.REGISTER);
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");

  const [turnout, setTurnout] = useState(null);
  const [results, setResults] = useState([]);
  const [auditLog, setAuditLog] = useState([]);
  const [showAudit, setShowAudit] = useState(false);

  const refreshDashboard = useCallback(async () => {
    try {
      const [t, r, a] = await Promise.all([api.turnout(), api.results(), api.auditLog()]);
      setTurnout(t);
      setResults(r);
      setAuditLog(a);
    } catch (e) {
      // dashboard refresh failing shouldn't block the voting flow
    }
  }, []);

  useEffect(() => {
    refreshDashboard();
    const id = setInterval(refreshDashboard, 4000);
    return () => clearInterval(id);
  }, [refreshDashboard]);

  return (
    <div style={styles.page}>
      <header style={styles.header}>
        <div>
          <h1 style={styles.h1}>Online Voting System</h1>
          <p style={styles.tagline}>OTP-verified · encrypted ballots · live from MySQL</p>
        </div>
        <ConnectionBadge />
      </header>

      <main style={styles.main}>
        <section style={styles.card}>
          {step === STEP.REGISTER && (
            <RegisterStep
              onDone={(em) => {
                setEmail(em);
                setError("");
                setStep(STEP.OTP);
                refreshDashboard();
              }}
              onError={setError}
            />
          )}
          {step === STEP.OTP && (
            <OtpStep
              email={email}
              onVerified={() => {
                setError("");
                setStep(STEP.VOTE);
                refreshDashboard();
              }}
              onError={setError}
            />
          )}
          {step === STEP.VOTE && (
            <VoteStep
              email={email}
              onVoted={() => {
                setError("");
                setStep(STEP.DONE);
                refreshDashboard();
              }}
              onError={setError}
            />
          )}
          {step === STEP.DONE && <DoneStep />}
          {error && <p style={styles.error}>{error}</p>}
        </section>

        <aside style={styles.sidebar}>
          <TurnoutCard turnout={turnout} />
          <ResultsCard results={results} />
          <AuditCard log={auditLog} show={showAudit} setShow={setShowAudit} />
        </aside>
      </main>
    </div>
  );
}

function ConnectionBadge() {
  const [ok, setOk] = useState(null);
  useEffect(() => {
    const check = () =>
      fetch((import.meta.env.VITE_API_URL || "http://localhost:5000") + "/api/health")
        .then((r) => setOk(r.ok))
        .catch(() => setOk(false));
    check();
    const id = setInterval(check, 5000);
    return () => clearInterval(id);
  }, []);
  return (
    <div style={styles.badge}>
      <span style={{ ...styles.dot, background: ok ? "#6b9e78" : ok === false ? "#c47262" : "#c9b98a" }} />
      {ok === null ? "Checking backend…" : ok ? "Backend connected" : "Backend unreachable"}
    </div>
  );
}

function RegisterStep({ onDone, onError }) {
  const [form, setForm] = useState({ rollNumber: "", name: "", email: "" });
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    onError("");
    try {
      await api.register(form);
      await api.sendOtp({ email: form.email });
      onDone(form.email);
    } catch (err) {
      onError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={submit} style={styles.form}>
      <StepLabel n={1} label="Voter Registration" />
      <Field label="Roll number" value={form.rollNumber}
        onChange={(v) => setForm({ ...form, rollNumber: v })} required />
      <Field label="Full name" value={form.name}
        onChange={(v) => setForm({ ...form, name: v })} required />
      <Field label="Email" type="email" value={form.email}
        onChange={(v) => setForm({ ...form, email: v })} required />
      <button type="submit" disabled={loading} style={styles.primaryBtn}>
        {loading ? "Registering…" : "Register & send OTP"}
      </button>
    </form>
  );
}

function OtpStep({ email, onVerified, onError }) {
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [sentOtp, setSentOtp] = useState("");

  useEffect(() => {
    api.sendOtp({ email }).then((r) => setSentOtp(r.demoOtp)).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    onError("");
    try {
      await api.verifyOtp({ email, otp });
      onVerified();
    } catch (err) {
      onError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={submit} style={styles.form}>
      <StepLabel n={2} label="OTP Verification" />
      <p style={styles.muted}>Sent to <strong>{email}</strong></p>
      {sentOtp && (
        <p style={styles.demoNote}>
          Demo mode — no SMS/email gateway wired up. Your OTP: <strong>{sentOtp}</strong>
        </p>
      )}
      <Field label="Enter 6-digit OTP" value={otp} onChange={setOtp} required maxLength={6} />
      <button type="submit" disabled={loading} style={styles.primaryBtn}>
        {loading ? "Verifying…" : "Verify OTP"}
      </button>
    </form>
  );
}

function VoteStep({ email, onVoted, onError }) {
  const [candidates, setCandidates] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.candidates().then(setCandidates).catch((e) => onError(e.message));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const submit = async () => {
    if (!selected) return onError("Pick a candidate first");
    setLoading(true);
    onError("");
    try {
      await api.vote({ email, candidateId: selected });
      onVoted();
    } catch (err) {
      onError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.form}>
      <StepLabel n={3} label="Cast Your Vote" />
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {candidates.map((c) => (
          <label key={c.id} style={{
            ...styles.candidateRow,
            borderColor: selected === c.id ? "var(--navy)" : "var(--card-border)",
            background: selected === c.id ? "#eef2f6" : "#fff",
          }}>
            <input type="radio" name="candidate" value={c.id}
              checked={selected === c.id}
              onChange={() => setSelected(c.id)} />
            <span>
              <strong>{c.name}</strong>
              <span style={styles.muted}> — {c.party}</span>
            </span>
          </label>
        ))}
      </div>
      <button onClick={submit} disabled={loading} style={styles.primaryBtn}>
        {loading ? "Casting vote…" : "Cast Vote"}
      </button>
    </div>
  );
}

function DoneStep() {
  return (
    <div style={styles.form}>
      <StepLabel n={4} label="Vote Recorded" />
      <p>Your vote has been encrypted and stored. Thank you for voting.</p>
      <p style={styles.muted}>Check the live results panel — it updates from the database in real time.</p>
    </div>
  );
}

function StepLabel({ n, label }) {
  return (
    <div style={styles.stepLabel}>
      <span style={styles.stepNum}>{n}</span>
      <h2 style={styles.h2}>{label}</h2>
    </div>
  );
}

function Field({ label, value, onChange, type = "text", required, maxLength }) {
  return (
    <label style={styles.field}>
      <span style={styles.fieldLabel}>{label}</span>
      <input
        type={type}
        value={value}
        required={required}
        maxLength={maxLength}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}

function TurnoutCard({ turnout }) {
  return (
    <div style={styles.sideCard}>
      <h3 style={styles.h3}>Live Turnout</h3>
      {turnout ? (
        <>
          <div style={styles.turnoutBig}>{turnout.turnoutPercent}%</div>
          <p style={styles.muted}>{turnout.totalVotes} of {turnout.totalVoters} registered voters have voted</p>
        </>
      ) : (
        <p style={styles.muted}>Loading…</p>
      )}
    </div>
  );
}

function ResultsCard({ results }) {
  const max = Math.max(1, ...results.map((r) => r.voteCount));
  return (
    <div style={styles.sideCard}>
      <h3 style={styles.h3}>Results (live)</h3>
      {results.map((r) => (
        <div key={r.id} style={{ marginBottom: 10 }}>
          <div style={styles.resultRow}>
            <span>{r.name}</span>
            <span style={styles.muted}>{r.voteCount}</span>
          </div>
          <div style={styles.barTrack}>
            <div style={{ ...styles.barFill, width: `${(r.voteCount / max) * 100}%` }} />
          </div>
        </div>
      ))}
    </div>
  );
}

function AuditCard({ log, show, setShow }) {
  return (
    <div style={styles.sideCard}>
      <button onClick={() => setShow(!show)} style={styles.linkBtn}>
        {show ? "Hide audit log" : "Show audit log"}
      </button>
      {show && (
        <div style={styles.auditList}>
          {log.map((e) => (
            <div key={e.id} style={styles.auditRow}>
              <span style={styles.auditType}>{e.event_type}</span>
              <span style={styles.muted}>{e.details}</span>
              <span style={styles.auditTime}>
                {new Date(e.created_at).toLocaleTimeString()}
              </span>
            </div>
          ))}
          {log.length === 0 && <p style={styles.muted}>No events yet.</p>}
        </div>
      )}
    </div>
  );
}

const styles = {
  page: { minHeight: "100vh", padding: "32px 24px", maxWidth: 1100, margin: "0 auto" },
  header: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28 },
  h1: { fontSize: 30, color: "var(--navy)" },
  tagline: { color: "var(--text-muted)", margin: "6px 0 0", fontSize: 14 },
  badge: { display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: "var(--text-muted)",
    background: "#fff", border: "1px solid var(--card-border)", borderRadius: 20, padding: "6px 14px" },
  dot: { width: 8, height: 8, borderRadius: "50%", display: "inline-block" },
  main: { display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: 24, alignItems: "start" },
  card: { background: "var(--card)", border: "1px solid var(--card-border)", borderRadius: 14, padding: 28 },
  form: { display: "flex", flexDirection: "column", gap: 14 },
  stepLabel: { display: "flex", alignItems: "center", gap: 10, marginBottom: 6 },
  stepNum: { width: 28, height: 28, borderRadius: "50%", background: "var(--navy)", color: "#fff",
    display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, fontWeight: 600, flexShrink: 0 },
  h2: { fontSize: 20, color: "var(--text)" },
  h3: { fontSize: 15, color: "var(--navy)", marginBottom: 12 },
  field: { display: "flex", flexDirection: "column", gap: 5 },
  fieldLabel: { fontSize: 12.5, color: "var(--text-muted)", fontWeight: 500 },
  primaryBtn: { background: "var(--navy)", color: "#fff", padding: "11px 18px", fontSize: 14.5, marginTop: 6 },
  muted: { color: "var(--text-muted)", fontSize: 13 },
  demoNote: { fontSize: 12.5, background: "#fbf1ee", border: "1px solid #f0d9d2", color: "var(--blush-deep)",
    borderRadius: 8, padding: "8px 12px" },
  error: { color: "var(--error)", fontSize: 13.5, marginTop: 12 },
  candidateRow: { display: "flex", alignItems: "center", gap: 10, border: "1px solid var(--card-border)",
    borderRadius: 10, padding: "10px 14px", cursor: "pointer" },
  sidebar: { display: "flex", flexDirection: "column", gap: 16 },
  sideCard: { background: "var(--card)", border: "1px solid var(--card-border)", borderRadius: 14, padding: 20 },
  turnoutBig: { fontSize: 38, fontWeight: 700, color: "var(--navy)", fontFamily: "'Source Serif 4', serif" },
  resultRow: { display: "flex", justifyContent: "space-between", fontSize: 13.5, marginBottom: 4 },
  barTrack: { height: 7, borderRadius: 4, background: "#eef1f5", overflow: "hidden" },
  barFill: { height: "100%", background: "var(--blush)", borderRadius: 4 },
  linkBtn: { background: "none", color: "var(--navy)", fontSize: 13.5, padding: 0, textDecoration: "underline" },
  auditList: { marginTop: 12, display: "flex", flexDirection: "column", gap: 8, maxHeight: 220, overflowY: "auto" },
  auditRow: { display: "flex", flexDirection: "column", gap: 2, borderBottom: "1px solid var(--card-border)", paddingBottom: 6, fontSize: 12.5 },
  auditType: { fontWeight: 600, color: "var(--navy)" },
  auditTime: { color: "#a8b3c2", fontSize: 11 },
};
